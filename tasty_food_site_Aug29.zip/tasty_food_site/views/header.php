<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    
    <!-- the head section -->
    <head>
        <title>Tasty Food</title>
        <link rel="stylesheet" type="text/css" href="<?php echo $app_path ?>main.css" />
    </head>

    <!-- the body section -->
    <body>
    <div id="page">
			<div id="header">
				<h1><a href="<?php echo $app_path ?>">Fried Dumpling</a></h1>
				<ul id="navbar">
					<li>
						<a href="<?php echo $app_path ?>index.php">Home</a>
					</li>
					<li>
						<a href="#">Menu</a>
					</li>
					<li>
						<a href="#">Order</a>
					</li>
					<li>
						<a href="#">Contact us</a>
					</li>
				</ul>			 	 				
			</div><!-- header -->
        <div id="main">

