<?php include '../views/header.php'; ?>
<?php include '../views/sidebar.php'; ?>
<div id="content">
    <!-- display product -->
    <?php include 'item.php'; ?>
</div>
<?php include '../views/footer.php'; ?>